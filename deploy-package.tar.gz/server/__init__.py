"""Server package for ak-chars backend."""
